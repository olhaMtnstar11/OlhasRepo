<?php
    wp_footer();
    ?>

<footer class="footer text-center py-2 theme-bg-dark">
		   
           <p class="copyright"><a href="">Olhas new team</a></p>
    <?php
    dynamic_sidebar('footer-1');
    ?>
       </footer>
   
   </div>
	

</body>
</html>



